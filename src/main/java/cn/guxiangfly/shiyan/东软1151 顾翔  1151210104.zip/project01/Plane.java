package cn.guxiangfly.shiyan.project01;

/**
 * Plane
 *
 * @author guxiang
 * @date 2017/10/19
 */
public class Plane implements Common{
    @Override
    public double getSpeed(double A, double B, double C) {
        return A;
    }
}
