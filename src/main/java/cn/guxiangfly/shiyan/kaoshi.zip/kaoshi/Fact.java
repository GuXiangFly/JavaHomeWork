package cn.guxiangfly.shiyan.kaoshi;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * Fact
 *
 * @author guxiang
 * @date 2017/12/31
 */
public class Fact <T>{
    public static  <T> T getobjectByCeneric(Class<T> tClass,String username,String password) throws Exception {
        //Class<T> clazz = (Class<T>) t.getClass();
       Constructor<T> constructor = tClass.getConstructor(String.class,String.class);
        T t1 = constructor.newInstance(username,password);
        System.out.println(t1.toString());
        return t1;
    }



}
