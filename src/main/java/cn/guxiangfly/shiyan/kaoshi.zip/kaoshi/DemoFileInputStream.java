package cn.guxiangfly.shiyan.kaoshi;

/**
 * DemoFileInputStream
 *
 * @author guxiang
 * @date 2018/1/2
 */
public class DemoFileInputStream {

}
