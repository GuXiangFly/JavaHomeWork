package cn.guxiangfly.shiyan.kaoshi;

/**
 * MyRuntimeException
 *
 * @author guxiang
 * @date 2018/1/9
 */
public class MyRuntimeException extends RuntimeException {

}
