package cn.guxiangfly.shiyan.kaoshi;

/**
 * Water
 *
 * @author guxiang
 * @date 2018/1/9
 */
public class Water extends Drink{
    @Override
    public void drinkit() {
        System.out.println("我喝矿泉水");
    }
}
