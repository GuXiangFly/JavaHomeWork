package cn.guxiangfly.shiyan.kaoshi;

/**
 * Milk
 *
 * @author guxiang
 * @date 2018/1/9
 */
public class Milk extends Drink {
    @Override
    public void drinkit() {
        System.out.println("我喝牛奶");
    }
}
