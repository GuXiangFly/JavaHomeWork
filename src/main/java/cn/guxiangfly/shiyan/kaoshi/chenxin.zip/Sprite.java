package cn.guxiangfly.shiyan.kaoshi;

/**
 * Sprite
 *
 * @author guxiang
 * @date 2018/1/9
 */
public class Sprite extends Drink {
    @Override
    public void drinkit() {
        System.out.println("我喝雪碧");
    }
}
