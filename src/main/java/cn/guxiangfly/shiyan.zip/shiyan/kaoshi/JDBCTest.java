package cn.guxiangfly.shiyan.kaoshi;

import org.junit.Test;

import java.sql.*;

/**
 * JDBCTest
 *
 * @author guxiang
 * @date 2018/1/1
 */
public class JDBCTest {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        String sql;
        // MySQL的JDBC URL编写方式：jdbc:mysql://主机名称：连接端口/数据库的名称?参数=值
        // 避免中文乱码要指定useUnicode和characterEncoding
        // 执行数据库操作之前要在数据库管理系统上创建一个数据库，名字自己定，
        // 下面语句之前就要先创建javademo数据库
        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/shopbook?"
                + "user=root&password=root&useUnicode=true&characterEncoding=UTF8";
        conn= DriverManager.getConnection(url);
        sql="SELECT * FROM t_admin";
        PreparedStatement statement = conn.prepareStatement(sql);
        ResultSet resultSet = statement.executeQuery(sql);
        ResultSetMetaData metaData = resultSet.getMetaData();

        int columnCount = metaData.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
            String catalogName = metaData.getCatalogName(i + 1);
            int columnType = metaData.getColumnType(i + 1);
            String columnTypeName = metaData.getColumnTypeName(i + 1);

            System.out.println("columnName :" + catalogName +",columnType : "+ columnType +", columnTypeName: "+columnTypeName);
        }

   /*     try {
            // 之所以要使用下面这条语句，是因为要使用MySQL的驱动，所以我们要把它驱动起来，
            // 可以通过Class.forName把它加载进去，也可以通过初始化来驱动起来，下面三种形式都可以
            Class.forName("com.mysql.jdbc.Driver");// 动态加载mysql驱动
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            conn.close();
        }*/
    }

    @Test
    public void testupdate() throws Exception{
        Connection connection;
        String sql = "insert into t_admin (password, username) VALUES ('123456','xiaoming2')";

        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/shopbook?user=root&password=root";
         connection = DriverManager.getConnection(url);
        PreparedStatement statement = connection.prepareStatement(sql);
        boolean execute = statement.execute();
        connection.close();
    }
}
