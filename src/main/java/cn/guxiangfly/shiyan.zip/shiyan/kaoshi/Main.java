package cn.guxiangfly.shiyan.kaoshi;

/**
 * Main
 *
 * @author guxiang
 * @date 2017/12/31
 */
public class Main {

    public static void main(String[] args) throws Exception {

        Person person1 = Fact.getobjectByCeneric(Person.class,"guxiang","guxiang");

    }
}
