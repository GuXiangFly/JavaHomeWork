package cn.guxiangfly.shiyan.project01;

/**
 * Common
 *
 * @author guxiang
 * @date 2017/10/19
 */
public interface Common {


     double  getSpeed(double A ,double B ,double C);
}
